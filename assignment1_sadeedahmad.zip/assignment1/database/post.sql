drop table if exists post;
create table post (    
    post_id integer not null primary key autoincrement,    
    username varchar(80) not null, 
    title varchar(80) not null, 
    msg text not null, 
    post_date TIMESTAMP DEFAULT (DATE (CURRENT_TIMESTAMP, 'LOCALTIME')) NOT NULL
); 
insert into post (username, title, msg) values ("Sadeed",  "World Cup", "Australia has won 5 cricket world cups");
insert into post (username, title, msg) values ("Ahmad",  "Birthday", "Today is my birthday");
insert into post (username, title, msg) values ("John",  "Sick", "I am sick today");
insert into post (username, title, msg, post_date) values ("Steve",  "Ashes update", "Australia will win ashses in 2019", "2018-07-07");
insert into post (username, title, msg, post_date) values ("Mick",  "weather update", "Today is a good day","2017-01-27");
insert into post (username, title, msg, post_date) values ("Josh",  "day update", "I am having a good day today ", "2018-06-01");
insert into post (username, title, msg) values ("Steve",  "sports update", "S. Smith has hit a century again. ");
insert into post (username, title, msg) values ("Sadeed",  "Web App Dev", "I am done with assignment. Yahoooo");
insert into post (username, title, msg) values ("Sadeed",  "Ashes update", "Australia's selectors have dropped their established No. 3 Usman Khawaja and also spelled James Pattinson for the fourth Ashes Test at Old Trafford, signalling a change in approach following a narrow defeat at Headingley.
Khawaja's omission meets the desire of selection chairman Trevor Hohns to address the abundance of left-handers at the top of the order, making it likely that Marnus Labuschagne will take over at first drop after Khawaja had occipied the position for most of the past four years.");



drop table if exists comment;
create table comment (    
    comment_id integer not null primary key autoincrement,    
    comment_username varchar(80) not null,  
    comment_msg text not null,
    post_id integer,
    CONSTRAINT fk_post
        FOREIGN KEY (post_id)
    REFERENCES post(post_id)
    ON DELETE CASCADE
); 

insert into comment (comment_username, comment_msg, post_id) values ("User1",  "Marcus Harris has been retained ", "9");
insert into comment (comment_username, comment_msg, post_id) values ("User2",  "Its not good", "9");
insert into comment (comment_username, comment_msg, post_id) values ("User1",  "I think its a good move", "9");
insert into comment (comment_username, comment_msg, post_id) values ("User5",  "I am excited ", "5");
insert into comment (comment_username, comment_msg, post_id) values ("User3",  "Well, its good", "2");
insert into comment (comment_username, comment_msg, post_id) values ("User2",  "should be fine", "6");
insert into comment (comment_username, comment_msg, post_id) values ("User78",  "Random Text ", "2");
insert into comment (comment_username, comment_msg, post_id) values ("User57",  "Random comment ", "4");
insert into comment (comment_username, comment_msg, post_id) values ("User22",  "Dont have any more energy to put random comment", "6");





