@extends('layouts.master')

@section('title')
  Delete Post
@endsection

@section('content')


<h3 class = "alert"> Comment has been deleted succefully !!! </h3> <br>






@endsection