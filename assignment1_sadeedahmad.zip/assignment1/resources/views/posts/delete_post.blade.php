@extends('layouts.master')

@section('title')
  Delete Post
@endsection

@section('content')


<h4 class = "alert"> Post has been deleted succefully !!! </h4> <br>



@endsection