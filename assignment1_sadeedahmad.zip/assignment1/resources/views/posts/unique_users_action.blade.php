 @extends('layouts.master')

@section('title')
  Unique Users Posts
@endsection

@section('content')



    <div class = "post"> 
      
      @foreach ($posts as $post)
          <div id = "post">
            <img src="{{asset('user.jpg')}}" width=100 height =100 alt="simpsons user">
            <p><b>User Name </b>:{{$post->username}}</p>
            <a href = "{{url("post_detail/$post->post_id")}}" > <b>Post Title:</b> {{$post->title}}</a><br>
            <p><b>Message :</b> {{$post->msg}}</p>
            <p><b>Date:</b> {{$post->post_date}}</p>
  
          </div><br> 
        @endforeach
    </div>
    
@endsection



            
