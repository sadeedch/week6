<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// route for home page showing all posts
Route::get('/', function(){
    $sql = "select * from post order by post_id DESC";
    $posts = DB::select($sql);
    // showing the total number of comments 
    $comments_number = DB::table('comment')->count('comment.post_id');
    return view('posts.home')->with('posts', $posts)->with('comments_number', $comments_number);
});

// route for recent post page
Route::get('recent_post', function(){
    $sql = "select * FROM post WHERE post_date > (SELECT DATETIME('now', '-7 day')) order by post_id DESC";
    $posts = DB::select($sql);
    return view('posts.recent_post')->with('posts', $posts); 
});

/* route for list of unique users
Shows all the unique users that have made a post. 
*/
Route::get('unique_users', function(){
    $sql = "select DISTINCT username from post ";
    $posts = DB::select($sql);
    return view('posts.unique_users')->with('posts', $posts); 
});

/* route for unique users action. when the user clicks on the username, 
all the posts made by that particular user are shown. 
*/
Route::get('unique_users_action/{username}', function($username){
    
    $posts = DB::select("select * from post where username = ?", [$username]);
    return view('posts.unique_users_action')->with('posts', $posts); 
});

// route for documentation page
Route::get('doc', function(){
    return view('posts.doc');
});

/* 
Route for post details page. This page shows all the details of the selected post 
and the comments associated with that post. It uses 2 functions. get_post() and get_comment() 
to retrieve the post and comments. 
*/
Route::get('post_detail/{post_id}', function($id){
    $post = get_post($id);
    $comments = get_comment($id);
    return view('posts.post_detail')->with('post', $post)->with('comments', $comments);
});
/* 
This funtion retreives the post when post detail route is hit. If there are no posts,
it shows an error otherwise it returns the post. 
*/
function get_post($id){
    $sql = "select * from post where post_id =?";    // ? is used as a placeholder for SQL sanitisation 
    $posts = DB::select($sql, array($id));
    if (count ($posts) != 1){                   // if id is not exactly to 1, raise an error. 
        die ("Error! Post not available");
    }
    $post = $posts[0];
    return $post;
}

/* 
This function retreives the comments associated with a particular post. 
*/
function get_comment($id){
    $sql = "select * from post, comment where post.post_id = comment.post_id and comment.post_id = ? ";    
    $comments = DB::select($sql, array($id));
    return $comments;
}


/* 
This route adds a new post. It uses add_post() function.
When a new psot is added, it redirects back to home page. 
*/
Route::post('add_post_action', function (){
    $username = request('username');
    $title = request('title');
    $msg = request('msg');

    if (empty($username))
        {echo "Error !! Username can not be empty, All fields are required for a post";
        exit;
        }
    if (empty($title))
        {echo "Error !! Title can not be empty, All fields are required for a post";
        exit;
        }
    if (empty($msg))
        {echo "Error !! Message can not be empty, All fields are required for a post";
        exit;
        }
    $new_post = add_post($username,$title, $msg);
    
    if ($new_post){
        return redirect (url("/"));    
    } 
});

/* 
add post function () adds a new post.
*/
function add_post($username,$title, $msg){
    $sql = "insert into post (username, title, msg) values (?,?,?)";
    DB::insert($sql, array($username,$title, $msg));
    $id = DB::getPdo()->lastInsertId();     //DB::getPdo()->lastInsertId()to fetch last inserted item's id
    return ($id);
}

/* 
Add comment action add a new comment to a particular post by using add_comment() function. 
when a comment is succesfully added, it redirects back to the post details page of that post. 
*/
Route::post('add_comment_action/{post_id}', function ($id){
    $post_id = $id;
    $username = request('comment_username');
    $msg = request('comment_msg');

    if (empty($username))
        {echo "Error !! Username can not be empty, All fields are required for a Comment";
        exit;
        }
    if (empty($msg))
        {echo "Error !! Comment Message can not be empty, All fields are required for a Comment";
        exit;
        }

    $new_comment = add_comment($username,$msg, $post_id);
    return redirect (url("post_detail/$id"));

});

/* 
This function adds a new comment to a particular post. 
*/
function add_comment($username,$msg, $post_id){
    $sql = "insert into comment (comment_username,  comment_msg, post_id) values (?,?,?)";
    DB::insert($sql, array($username, $msg, $post_id));
    
}


/* 
This route is used for updating a post. It returns to update_post page.
On that page, the post details are retreived and then edited. 
*/
Route::get('update_post/{post_id}', function($id){
    $post = get_post($id);
    return view('posts.update_post')->with('post', $post); 
});

/* 
update_post_action updates the post by using update_post() function. When the post is updated, 
it redirects back to post details page of that particular post. 
*/
Route::post('update_post_action', function (){
    $username = request ('username');
    $title = request('title');
    $msg = request('msg');
    $id = request('post_id');
    $post = update_post($username, $title, $msg, $id);
    return redirect (url("post_detail/$id"));     // this will redirect to item details. url() for absolute path 
});

/* 
This function is being used to update a particular post. 
*/
function update_post($username, $title, $msg, $id) {
    $sql = "update post set username = ?, title = ?, msg = ? where post_id = ?";
    DB::update($sql, array($username, $title, $msg, $id));
    }



/* 
This route is being used to delete a post. When this route is hit, it deletes a post and 
returns to delete_post page which shows the message of post has been deleted. It uses 
delete_post() function. 
*/
Route::get('delete_post/{post_id}', function($id){
    $post = delete_post($id);
    return view('posts.delete_post')->with('post', $post); 
});
/* 
This function is being used to delete a post. 
*/
function delete_post($id) {
    $sql = "delete from post where post_id = ?";
    DB::delete($sql, array($id));
} 

/*
This route is being used to delete a comment for a particular post. 
It gets the comment id and uses the delete_comment() function.
*/

Route::get('delete_comment/{comment_id}', function($id){
    $post = delete_comment($id);
    return view('posts.delete_comment');
});
/*
This function is being used to delete a comment for a particular post. It uses the comment_id 
as a parameter. 
*/
function delete_comment($id) {
    $sql = "delete from comment where comment_id = ?";
    DB::delete($sql, array($id));
} 








