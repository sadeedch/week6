<?php $__env->startSection('title'); ?>
  Update Post
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <form method="post" action= "<?php echo e(url("update_item_action")); ?>">
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="post_id" value="<?php echo e($post->post_id); ?>">

    <label>User Name:</label><br>
    <input type = "text" name ="username" value = "<?php echo e($post->username); ?>"><br>

    <label>Title:</label><br>
    <input type = "text" name ="title" value = "<?php echo e($post->title); ?>"><br>

    <label>Message:</label><br> 
    <textarea type="text" name ="msg" value = "<?php echo e($post->post_date); ?>">
    </textarea><br>

    <input type="submit" value="Update item">
  </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/WebAppDev/assignment1/resources/views/items/update_item.blade.php ENDPATH**/ ?>