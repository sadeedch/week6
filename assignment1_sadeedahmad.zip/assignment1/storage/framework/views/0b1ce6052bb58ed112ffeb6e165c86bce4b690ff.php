<?php $__env->startSection('title'); ?>
  Delete Post
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<h3 class = "alert"> Comment has been deleted succefully !!! </h3> <br>






<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/WebAppDev/assignment1/resources/views/posts/delete_comment.blade.php ENDPATH**/ ?>