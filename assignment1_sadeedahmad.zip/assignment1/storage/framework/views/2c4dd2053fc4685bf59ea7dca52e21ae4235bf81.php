<?php $__env->startSection('title'); ?>
  Comments
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-md-4">
      <img src="<?php echo e(asset('css/user.jpg')); ?>" width=100 height =100 alt="simpsons user">
      <h1>Title : <?php echo e($post->title); ?></h1>
      <p> <b>User Name:</b> <?php echo e($post->username); ?></p>
      <p> <b>Message:</b> <?php echo e($post->msg); ?></p>
      <p> <b>Date:</b> <?php echo e($post->post_date); ?></p>

      <p><a href = "<?php echo e(url("delete_item/$post->post_id")); ?>"> Delete Post</a></p>   
      <a href = "<?php echo e(url("update_item/$post->post_id")); ?>" > Update Post</a><br>
      
    </div>   


  <div class="col-md-8" >
      <form method="post" action="<?php echo e(url("add_comment_action")); ?>">
      <?php echo e(csrf_field()); ?>

        <div align = center style="background-color: #008080;">
          <label>User Name:</label><br><input type = "text" name ="comment_username"><br><br>
          <label>Comment:</label><br> <textarea type="text" rows="5" cols="70" name ="comment_msg"></textarea><br>
          <input type ="submit" value="Add new Comment">
        </div>
      </form><br> <br>
      <h3 align = center>Comments:</h3>
      
        <?php if($comments): ?>
          <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div style="background-color:lightblue">
              <p> <b>User Name: </b><?php echo e($comment->comment_username); ?></p>
              <p> <b>Comment: </b> <?php echo e($comment->comment_msg); ?></p>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
          <h4>There are no comments for this post</h4> 
        <?php endif; ?>
        

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/WebAppDev/assignment1/resources/views/items/item_detail.blade.php ENDPATH**/ ?>