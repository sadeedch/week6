<?php $__env->startSection('title'); ?>
  Delete Post
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<form method="post" action= "<?php echo e(url("delete_item_action")); ?>">
<?php echo e(csrf_field()); ?>

<h3> Post has been deleted succefully !!! </h3> <br>


</form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/WebAppDev/assignment1/resources/views/posts/delete_item.blade.php ENDPATH**/ ?>