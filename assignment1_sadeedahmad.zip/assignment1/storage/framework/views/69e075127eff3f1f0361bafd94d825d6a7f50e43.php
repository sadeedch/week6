 

<?php $__env->startSection('title'); ?>
  Home Page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
  <div class = "row" id = "content">
    <div class="col-md-4"> 
      <form method="post" action="<?php echo e(url("add_item_action")); ?>"> 
        <?php echo e(csrf_field()); ?>

        <label>User Name:</label><br><input type = "text" name ="username"><br>
        <label>Title:</label><br><input type = "text" name ="title"><br>
        <label>Message:</label><br> <textarea type="text" rows="5" cols="20" name ="msg"></textarea><br>
        <input type ="submit" value="Create Post">
      </form>
    </div>
    <div class="col-md-8" > 
      <?php if($posts): ?>   
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div id = "post">
            <img src="<?php echo e(asset('css/user.jpg')); ?>" width=100 height =100 alt="simsons user">
            <p><b>User Name </b>:<?php echo e($post->username); ?></p>
            <a href = "<?php echo e(url("item_detail/$post->post_id")); ?>" > <b>Post Title:</b> <?php echo e($post->title); ?></a><br>
            <p><b>Message :</b> <?php echo e($post->msg); ?></p>
            <p><b>Date:</b> <?php echo e($post->post_date); ?></p>
          </div><br> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php else: ?>
        No item Found
      <?php endif; ?>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/WebAppDev/assignment1/resources/views/items/item_list.blade.php ENDPATH**/ ?>