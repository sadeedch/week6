 

<?php $__env->startSection('title'); ?>
  Unique Users Posts
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



    <div class = "post"> 
      
      <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div id = "post">
            <img src="<?php echo e(asset('user.jpg')); ?>" width=100 height =100 alt="simpsons user">
            <p><b>User Name </b>:<?php echo e($post->username); ?></p>
            <a href = "<?php echo e(url("post_detail/$post->post_id")); ?>" > <b>Post Title:</b> <?php echo e($post->title); ?></a><br>
            <p><b>Message :</b> <?php echo e($post->msg); ?></p>
            <p><b>Date:</b> <?php echo e($post->post_date); ?></p>
  
          </div><br> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
<?php $__env->stopSection(); ?>



            

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/WebAppDev/assignment1/resources/views/posts/unique_users_action.blade.php ENDPATH**/ ?>