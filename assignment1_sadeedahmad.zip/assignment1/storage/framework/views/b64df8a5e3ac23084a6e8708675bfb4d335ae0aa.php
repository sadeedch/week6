 

<?php $__env->startSection('title'); ?>
  Unique Users
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



    <div align = center class="col-md-12" > 
      <h3> List of uniqure users</h3>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href = "<?php echo e(url("unique_users_action/$post->username")); ?>" > <?php echo e($post->username); ?></a><br> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
    </div>
    
<?php $__env->stopSection(); ?>



            

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/WebAppDev/assignment1/resources/views/posts/unique_users.blade.php ENDPATH**/ ?>