<?php $__env->startSection('title'); ?>
  Item List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  
  <h1><?php echo e($item->summary); ?></h1>
  <p> <?php echo e($item->details); ?></p>
  
  <a href = "<?php echo e(url("delete_item/$item->id")); ?>" > Delete Item</a><br>
  <a href = "<?php echo e(url("update_item/$item->id")); ?>" > Update Item</a><br>
  <a href = "<?php echo e(url("/")); ?>">Home</a>

<br>
<br>


   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/WebAppDev/week6/items/resources/views/items/item_detail.blade.php ENDPATH**/ ?>